--2. INSERT ACCOUNTS
INSERT INTO Accounts
    (FirstName, MiddleName, LastName, CityId, BirthDate, Email)
VALUES
    ('John', 'Smith', 'Smith', 34, '1975-07-21', 'j_smith@gmail.com'),
    ('Gosho', NULL, 'Petrov', 11, '1978-05-16', 'g_petrov@gmail.com'),
    ('Ivan', 'Petrovich', 'Pavlov', 59, '1849-09-26', 'i_pavlov@softuni.bg'),
    ('Friedrich', 'Wilhelm', 'Nietzsche', 2, '1844-10-15', 'f_nietzsche@softuni.bg')

--2. INSERT Trips

INSERT INTO Trips
    (RoomId, BookDate, ArrivalDate, ReturnDate, CancelDate)
VALUES
    (101, '2015-04-12', '2015-04-14', '2015-04-20', '2015-02-02'),
    (102, '2015-07-07', '2015-07-15', '2015-07-22', '2015-04-29'),
    (103, '2013-07-17', '2013-07-23', '2013-07-24', NULL),
    (104, '2012-03-17', '2012-03-31', '2012-04-01', '2012-01-10'),
    (109, '2017-08-07', '2017-08-28', '2017-08-29', NULL)


--3. Update
UPDATE Rooms
SET Price = Price * 1.14
WHERE HotelId IN (5, 7, 9)

--4. Delete
DELETE FROM AccountsTrips
WHERE AccountId = 47;

--5. EEE-Mails

--Select accounts whose emails start with the letter “e”. Select their first and last name, their birthdate in the format "MM-dd-yyyy", their city name, and their Email.
--Order them by city name (ascending)

SELECT a.FirstName, a.LastName, FORMAT(a.BirthDate, 'MM-dd-yyyy'), c.Name, a.Email
FROM Accounts a
    JOIN Cities c ON c.Id = a.CityId
WHERE LEFT(a.Email, 1) = 'e'
ORDER BY c.Name;

--6. City Statistics

--Select all cities with the count of hotels in them. Order them by the hotel count (descending), then by city name. Do not include cities, which have no hotels in them.

SELECT c.Name, COUNT(h.Name)
FROM Hotels h
    JOIN Cities c ON c.Id = h.CityId
GROUP BY c.Name
ORDER BY COUNT(h.Name) DESC

--7. Longest and Shortest Trips

--Find the longest and shortest trip for each account, in days. Filter the results to accounts with no middle name and trips, which are not cancelled (CancelDate is null).

--Order the results by Longest Trip days (descending), then by Shortest Trip (ascending).

