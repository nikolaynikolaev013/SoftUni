﻿using System;
namespace ProductShop.DataTransferObjects
{
    public class CategoryDto
    {
        public CategoryDto()
        {
        }

        public string Name { get; set; }

    }
}
