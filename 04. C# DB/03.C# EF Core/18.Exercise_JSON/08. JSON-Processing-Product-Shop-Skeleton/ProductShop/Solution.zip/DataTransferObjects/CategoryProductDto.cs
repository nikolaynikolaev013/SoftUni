﻿using System;
namespace ProductShop.DataTransferObjects
{
    public class CategoryProductDto
    {
        public CategoryProductDto()
        {
        }

        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
