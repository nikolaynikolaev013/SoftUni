﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=localhost,1433; Database=SoftUni;User=sa; Password=<YourStrong@Passw0rd>";
    }
}
