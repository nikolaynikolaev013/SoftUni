﻿using System;
using System.Xml.Serialization;

namespace CarDealer.DTO.Input
{
    [XmlType("Supplier")]
    public class SupplierInputModel
    {
        public SupplierInputModel()
        {
        }

        [XmlElement("name")]
        public string Name { get; set; }


        [XmlElement("isImporter")]
        public bool IsImporter { get; set; }
    }
}
