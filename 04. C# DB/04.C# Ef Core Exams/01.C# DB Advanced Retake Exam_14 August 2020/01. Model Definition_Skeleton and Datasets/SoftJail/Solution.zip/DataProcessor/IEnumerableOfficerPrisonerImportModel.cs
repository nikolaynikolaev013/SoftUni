﻿namespace SoftJail.DataProcessor
{
    internal interface IEnumerableOfficerPrisonerImportModel
    {
    }
}