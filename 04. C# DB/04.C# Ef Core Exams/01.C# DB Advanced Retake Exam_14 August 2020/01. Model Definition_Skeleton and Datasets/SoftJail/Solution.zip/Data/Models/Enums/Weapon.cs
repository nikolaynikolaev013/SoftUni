﻿using System;
namespace SoftJail.Data.Models.Enums
{
    public enum Weapon
    {
        Knife = 10,
        FlashPulse = 20,
        ChainRifle = 30,
        Pistol = 40,
        Sniper = 50
    }
}
