﻿namespace SoftJail.Data.Models
{
    public enum Position
    {
        Overseer = 10,
        Guard = 20,
        Watcher = 30,
        Labour = 40
    }
}