﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433; Database=BookShop;User=sa; Password=<YourStrong@Passw0rd>";
    }
}