﻿namespace VaporStore.Data.Models
{
    public enum PurchaseType
    {
        Retail,
        Digital
    }
}