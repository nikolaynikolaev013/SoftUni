﻿using System;
namespace VaporStore.Data.Models.Enums
{
    public enum PurchaseType
    {
        Retail,
        Digital
    }
}
