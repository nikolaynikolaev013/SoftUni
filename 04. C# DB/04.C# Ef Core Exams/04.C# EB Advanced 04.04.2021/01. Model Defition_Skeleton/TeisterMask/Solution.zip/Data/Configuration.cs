﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost,1433; Database=TeisterMask;User=sa; Password=<YourStrong@Passw0rd>";
    }
}
