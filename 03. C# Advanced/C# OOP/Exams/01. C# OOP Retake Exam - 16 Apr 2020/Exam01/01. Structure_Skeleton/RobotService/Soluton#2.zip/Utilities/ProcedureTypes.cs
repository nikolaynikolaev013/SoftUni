﻿using System;
namespace RobotService.Utilities
{
    public enum ProcedureTypes
    {
        Charge = 1,
        Chip = 2,
        Polish = 3,
        Rest = 4,
        TechCheck = 5,
        Work = 6
    }
}
