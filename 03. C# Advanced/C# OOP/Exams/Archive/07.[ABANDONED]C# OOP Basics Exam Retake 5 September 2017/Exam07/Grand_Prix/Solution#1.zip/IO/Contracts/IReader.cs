﻿using System;
namespace Grand_Prix.IO.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
