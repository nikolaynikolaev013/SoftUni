﻿using System;
namespace Grand_Prix.Models.Drivers
{
    public class EnduranceDriver : Driver
    {
        public EnduranceDriver()
        {
        }

        public override float Speed => throw new NotImplementedException();
    }
}
