﻿using System;
namespace PlayersAndMonsters.Common
{
    public enum CardTypes
    {
        Magic = 1,
        Trap = 2
    }
}
