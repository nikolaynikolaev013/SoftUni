﻿using System;
using System.Linq;
using PlayersAndMonsters.Common;
using PlayersAndMonsters.Models.BattleFields.Contracts;
using PlayersAndMonsters.Models.Players.Contracts;

namespace PlayersAndMonsters.Models.BattleFields
{
    public class BattleField :IBattleField
    {
        public BattleField()
        {
        }

        public void Fight(IPlayer attackPlayer, IPlayer enemyPlayer)
        {
            if (attackPlayer.IsDead || enemyPlayer.IsDead)
            {
                throw new ArgumentException("Player is dead!");
            }

            BeginnersLuckBonus(attackPlayer);
            BeginnersLuckBonus(enemyPlayer);

            bool attackerPlayerFirst = true;

            while (!attackPlayer.IsDead && !enemyPlayer.IsDead)
            {
                if (attackerPlayerFirst)
                {
                    //enemyPlayer.TakeDamage()
                }
                else
                {
                    //attackPlayer.TakeDamage();
                }

                attackerPlayerFirst = !attackerPlayerFirst;
            }
        }

        private void BeginnersLuckBonus(IPlayer attackPlayer)
        {
            Enum.TryParse(attackPlayer.GetType().Name, out PlayerTypes attackplayerEnum);
            if (attackplayerEnum == PlayerTypes.Beginner)
            {
                attackPlayer.Health += 40;
                foreach (var card in attackPlayer.CardRepository.Cards)
                {
                    card.DamagePoints += 30;
                }
            }
        }
    }
}
