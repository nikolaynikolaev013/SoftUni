﻿using System;
namespace PlayersAndMonsters.Common
{
    public enum PlayerTypes
    {
        Beginner = 1,
        Advanced = 2
    }
}
