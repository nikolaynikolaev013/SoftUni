﻿using System;
namespace PlayersAndMonsters.Common
{
    public enum CardTypes
    {
        MagicCard = 1,
        TrapCard = 2
    }
}
